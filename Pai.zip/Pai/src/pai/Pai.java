/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pai;

import Connection.Conexion;
import Ventanas.LoginJFrame;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author raxielh
 */
public class Pai {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        LoginJFrame login = new LoginJFrame();
        login.setVisible(true);
        
    }
    
   
    
}
